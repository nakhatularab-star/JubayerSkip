# JUBAYER SKIP — Privacy Policy

JUBAYER SKIP works only on your phone.

- It reads the YouTube app screen only to find the real Skip button.
- It does not collect, store or send account details, passwords, messages or other screen content.
- The only data stored is the date/time of each successful skip and your app settings, on your device.
- The app has no internet permission and shares nothing with anyone.
- You can clear the history at any time in the History tab.

Contact: (add your email here before publishing)
