package com.jubayer.skip

import android.content.Intent
import android.provider.Settings as AndroidSettings
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF00A86B)
private val GreenLight = Color(0xFF3DDC97)

private val DarkColors = darkColorScheme(
    primary = GreenLight, onPrimary = Color.Black,
    background = Color(0xFF0A0F0D), onBackground = Color(0xFFE8F1EC),
    surface = Color(0xFF131A17), onSurface = Color(0xFFE8F1EC),
    surfaceVariant = Color(0xFF1C2622), onSurfaceVariant = Color(0xFFA9BAB1),
    primaryContainer = Color(0xFF0F3D2B), onPrimaryContainer = Color(0xFFB9F6D8)
)
private val LightColors = lightColorScheme(
    primary = Green, onPrimary = Color.White,
    background = Color(0xFFF5FAF7), onBackground = Color(0xFF101614),
    surface = Color.White, onSurface = Color(0xFF101614),
    surfaceVariant = Color(0xFFE6F0EB), onSurfaceVariant = Color(0xFF4A5A52),
    primaryContainer = Color(0xFFD3F5E5), onPrimaryContainer = Color(0xFF00391F)
)

@Composable
fun App(act: MainActivity) {
    val ctx = LocalContext.current
    val repo = remember { SettingsRepo(ctx.applicationContext) }
    val st by repo.flow.collectAsStateWithLifecycle(AppSettings())
    val dark = when (st.theme) {
        1 -> false
        2 -> true
        else -> androidx.compose.foundation.isSystemInDarkTheme()
    }
    androidx.compose.material3.MaterialTheme(colorScheme = if (dark) DarkColors else LightColors) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Main(act, repo, st)
        }
    }
}

@Composable
fun Main(act: MainActivity, repo: SettingsRepo, st: AppSettings) {
    val ctx = LocalContext.current
    val dao = remember { AppDb.get(ctx).dao() }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val items = listOf(
        R.string.nav_home to Icons.Filled.Home,
        R.string.nav_history to Icons.Filled.DateRange,
        R.string.nav_settings to Icons.Filled.Settings,
        R.string.nav_about to Icons.Filled.Info
    )
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(icon, contentDescription = null) },
                        label = { Text(stringResource(label)) }
                    )
                }
            }
        }
    ) { pad ->
        when (tab) {
            0 -> HomeScreen(pad, act, repo, st, dao)
            1 -> HistoryScreen(pad, dao)
            2 -> SettingsScreen(pad, act, repo, st)
            else -> AboutScreen(pad)
        }
    }
}

// ---------- small building blocks ----------
@Composable
fun SkipLogo(dp: Dp) {
    Canvas(Modifier.size(dp)) {
        val w = this.size.width
        drawRoundRect(Green, size = this.size, cornerRadius = CornerRadius(w * 0.24f))
        fun tri(x: Float) {
            val p = Path().apply {
                moveTo(w * x, w * 0.3f); lineTo(w * (x + 0.22f), w * 0.5f)
                lineTo(w * x, w * 0.7f); close()
            }
            drawPath(p, Color.White)
        }
        tri(0.22f); tri(0.43f)
        drawRect(Color.White, topLeft = Offset(w * 0.68f, w * 0.3f), size = Size(w * 0.07f, w * 0.4f))
    }
}

@Composable
fun SCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier.fillMaxWidth().animateContentSize(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) { Column(Modifier.padding(16.dp), content = content) }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier) {
    SCard(modifier) {
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.size(6.dp))
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun SwitchRow(title: String, desc: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            if (desc != null) Text(desc, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(10.dp))
        Text(label, modifier = Modifier.padding(vertical = 10.dp))
    }
}

@Composable
fun Title(text: String) = Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold)

private fun startOfToday(): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

// ---------- HOME ----------
@Composable
fun HomeScreen(pad: PaddingValues, act: MainActivity, repo: SettingsRepo, st: AppSettings, dao: SkipDao) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val total by remember { dao.total() }.collectAsStateWithLifecycle(0)
    val recent by remember { dao.recent() }.collectAsStateWithLifecycle(emptyList<SkipEvent>())
    val fmt = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }
    val active = st.autoSkip && act.serviceOn
    val dot by animateColorAsState(if (act.serviceOn) Green else Color(0xFFB00020), label = "dot")

    Column(
        Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SkipLogo(56.dp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(stringResource(R.string.app_name), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary)
                Text(stringResource(R.string.subtitle), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        SCard {
            SwitchRow(
                stringResource(R.string.auto_skip),
                stringResource(if (st.autoSkip) R.string.on else R.string.off),
                st.autoSkip
            ) { v -> scope.launch { repo.setAutoSkip(v) } }
            if (!act.serviceOn) {
                Spacer(Modifier.size(10.dp))
                Button(
                    onClick = { ctx.startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(stringResource(R.string.enable_service)) }
            }
        }

        SCard {
            Text(stringResource(R.string.service_status), fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.size(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Spacer(Modifier.size(12.dp).background(dot, CircleShape))
                Spacer(Modifier.width(10.dp))
                Text(
                    stringResource(if (active) R.string.service_on else if (act.serviceOn) R.string.service_on else R.string.service_off),
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            StatCard(stringResource(R.string.ads_skipped), total.toString(), Modifier.weight(1f))
            StatCard(stringResource(R.string.time_saved), fmtTime(ctx, total), Modifier.weight(1f))
        }

        SCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.floating_button), fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(
                    stringResource(if (st.floating) R.string.on else R.string.off),
                    color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold
                )
            }
        }

        SCard {
            Title(stringResource(R.string.recent_activity))
            Spacer(Modifier.size(8.dp))
            if (recent.isEmpty()) {
                Text(stringResource(R.string.no_activity), color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                recent.take(5).forEach {
                    Text(fmt.format(Date(it.time)), modifier = Modifier.padding(vertical = 4.dp))
                }
            }
        }

        SCard {
            Title(stringResource(R.string.quick_settings))
            Spacer(Modifier.size(8.dp))
            SwitchRow(stringResource(R.string.floating_button), null, st.floating) { v ->
                scope.launch { repo.setFloating(v) }
            }
            Spacer(Modifier.size(8.dp))
            SwitchRow(stringResource(R.string.battery_saver), null, st.saver) { v ->
                scope.launch { repo.setSaver(v) }
            }
        }
    }
}

// ---------- HISTORY ----------
@Composable
fun HistoryScreen(pad: PaddingValues, dao: SkipDao) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val total by remember { dao.total() }.collectAsStateWithLifecycle(0)
    val today by remember { dao.since(startOfToday()) }.collectAsStateWithLifecycle(0)
    val recent by remember { dao.recent() }.collectAsStateWithLifecycle(emptyList<SkipEvent>())
    val fmt = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }
    val dayFmt = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
    var confirm by remember { mutableStateOf(false) }
    val byDay = remember(recent) { recent.groupBy { dayFmt.format(Date(it.time)) }.entries.take(7) }

    LazyColumn(
        Modifier.fillMaxSize().padding(pad),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text(stringResource(R.string.history_title), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard(stringResource(R.string.today), today.toString(), Modifier.weight(1f))
                StatCard(stringResource(R.string.total), total.toString(), Modifier.weight(1f))
                StatCard(stringResource(R.string.time_saved), fmtTime(ctx, total), Modifier.weight(1.4f))
            }
        }
        if (byDay.isNotEmpty()) item {
            SCard {
                Title(stringResource(R.string.daily_stats))
                Spacer(Modifier.size(8.dp))
                byDay.forEach { (day, list) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                        Text(day, modifier = Modifier.weight(1f))
                        Text(list.size.toString(), fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
        item {
            OutlinedButton(onClick = { confirm = true }, enabled = total > 0, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Delete, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.clear_history))
            }
        }
        if (recent.isEmpty()) item {
            Text(stringResource(R.string.no_activity), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        items(recent, key = { it.id }) {
            SCard { Text(fmt.format(Date(it.time))) }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(stringResource(R.string.clear_history)) },
            text = { Text(stringResource(R.string.clear_confirm)) },
            confirmButton = {
                TextButton(onClick = { confirm = false; scope.launch { dao.clear() } }) {
                    Text(stringResource(R.string.delete))
                }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

// ---------- SETTINGS ----------
@Composable
fun SettingsScreen(pad: PaddingValues, act: MainActivity, repo: SettingsRepo, st: AppSettings) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var showPrivacy by remember { mutableStateOf(false) }
    val version = remember {
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (_: Throwable) { "" }
    }

    Column(
        Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(stringResource(R.string.nav_settings), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)

        SCard {
            Title(stringResource(R.string.language))
            val langs = listOf(
                "" to stringResource(R.string.lang_system),
                "bn" to "বাংলা",
                "en" to "English",
                "ar" to "العربية"
            )
            langs.forEach { (tag, label) ->
                RadioRow(label, st.lang == tag) {
                    scope.launch { repo.setLang(tag) }
                    AppCompatDelegate.setApplicationLocales(
                        if (tag.isEmpty()) LocaleListCompat.getEmptyLocaleList()
                        else LocaleListCompat.forLanguageTags(tag)
                    )
                }
            }
        }

        SCard {
            Title(stringResource(R.string.theme))
            RadioRow(stringResource(R.string.theme_system), st.theme == 0) { scope.launch { repo.setTheme(0) } }
            RadioRow(stringResource(R.string.theme_light), st.theme == 1) { scope.launch { repo.setTheme(1) } }
            RadioRow(stringResource(R.string.theme_dark), st.theme == 2) { scope.launch { repo.setTheme(2) } }
        }

        SCard {
            Title(stringResource(R.string.auto_skip_settings))
            Spacer(Modifier.size(8.dp))
            SwitchRow(stringResource(R.string.auto_skip), stringResource(R.string.auto_skip_desc), st.autoSkip) { v ->
                scope.launch { repo.setAutoSkip(v) }
            }
        }

        SCard {
            Title(stringResource(R.string.floating_settings))
            Spacer(Modifier.size(8.dp))
            SwitchRow(stringResource(R.string.floating_button), stringResource(R.string.floating_desc), st.floating) { v ->
                scope.launch { repo.setFloating(v) }
            }
        }

        SCard {
            Title(stringResource(R.string.battery_saver))
            Spacer(Modifier.size(8.dp))
            SwitchRow(stringResource(R.string.battery_saver), stringResource(R.string.battery_saver_desc), st.saver) { v ->
                scope.launch { repo.setSaver(v) }
            }
        }

        SCard {
            Title(stringResource(R.string.accessibility_permission))
            Spacer(Modifier.size(6.dp))
            Text(stringResource(R.string.accessibility_desc), fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.size(6.dp))
            Text(
                stringResource(if (act.serviceOn) R.string.service_on else R.string.service_off),
                fontWeight = FontWeight.SemiBold,
                color = if (act.serviceOn) MaterialTheme.colorScheme.primary else Color(0xFFB00020)
            )
            Spacer(Modifier.size(8.dp))
            Button(
                onClick = { ctx.startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)) },
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.open_settings)) }
        }

        SCard {
            OutlinedButton(onClick = { showPrivacy = true }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.privacy_policy))
            }
            Spacer(Modifier.size(10.dp))
            Row {
                Text(stringResource(R.string.app_version), modifier = Modifier.weight(1f))
                Text(version, fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showPrivacy) {
        AlertDialog(
            onDismissRequest = { showPrivacy = false },
            title = { Text(stringResource(R.string.privacy_policy)) },
            text = { Text(stringResource(R.string.privacy_text), modifier = Modifier.verticalScroll(rememberScrollState())) },
            confirmButton = { TextButton(onClick = { showPrivacy = false }) { Text(stringResource(R.string.close)) } }
        )
    }
}

// ---------- ABOUT ----------
@Composable
fun AboutScreen(pad: PaddingValues) {
    val ctx = LocalContext.current
    val version = remember {
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (_: Throwable) { "" }
    }
    Column(
        Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.size(10.dp))
        SkipLogo(96.dp)
        Text(stringResource(R.string.app_name), fontSize = 26.sp, fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.primary)
        Text(stringResource(R.string.subtitle), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("v$version", fontWeight = FontWeight.SemiBold)
        SCard {
            Title(stringResource(R.string.about_title))
            Spacer(Modifier.size(6.dp))
            Text(stringResource(R.string.about_text))
        }
        SCard {
            Title(stringResource(R.string.time_saved))
            Spacer(Modifier.size(6.dp))
            Text(stringResource(R.string.time_assumption))
        }
        SCard {
            Title(stringResource(R.string.privacy_policy))
            Spacer(Modifier.size(6.dp))
            Text(stringResource(R.string.privacy_text))
        }
    }
}
