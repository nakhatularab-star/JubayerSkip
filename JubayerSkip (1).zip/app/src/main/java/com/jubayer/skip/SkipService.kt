package com.jubayer.skip

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

private const val YT = "com.google.android.youtube"

/**
 * Presses ONLY a genuine, visible, enabled YouTube "Skip" button.
 * Runs only when the user enabled the service AND turned Auto Skip on.
 * The floating button is drawn by this service (accessibility overlay), so
 * no extra "draw over other apps" permission is needed.
 */
class SkipService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    @Volatile private var st = AppSettings()
    private var lastScan = 0L
    private var lastClick = 0L

    private var wm: WindowManager? = null
    private var bubble: TextView? = null
    private lateinit var repo: SettingsRepo

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        repo = SettingsRepo(applicationContext)
        scope.launch {
            repo.flow.collect { st = it; updateBubble() }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !st.autoSkip) return
        if (event.packageName?.toString() != YT) return

        val now = SystemClock.elapsedRealtime()
        val gap = if (st.saver) 1200L else 400L
        if (now - lastScan < gap) return
        lastScan = now

        try {
            val root = rootInActiveWindow ?: return
            if (root.packageName?.toString() != YT) return
            val skip = findSkip(root) ?: return
            if (now - lastClick < 1500L) return
            if (click(skip)) {
                lastClick = now
                record()
            }
        } catch (_: Throwable) {
            // UI changed or node vanished: do nothing, safely.
        }
    }

    private fun findSkip(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (n in root.findAccessibilityNodeInfosByViewId("$YT:id/skip_ad_button")) {
            if (genuine(n)) return n
        }
        for (key in listOf("Skip ads", "Skip ad", "Skip")) {
            for (n in root.findAccessibilityNodeInfosByText(key)) {
                if (exactSkipLabel(n) && genuine(n)) return n
            }
        }
        return null
    }

    private fun exactSkipLabel(n: AccessibilityNodeInfo): Boolean {
        val t = (n.text ?: n.contentDescription)?.toString()?.trim()?.lowercase() ?: return false
        return t == "skip" || t == "skip ad" || t == "skip ads"
    }

    private fun genuine(n: AccessibilityNodeInfo): Boolean {
        if (!n.isVisibleToUser || !n.isEnabled) return false
        val r = Rect()
        n.getBoundsInScreen(r)
        return r.width() > 0 && r.height() > 0
    }

    private fun click(n: AccessibilityNodeInfo): Boolean {
        val target = when {
            n.isClickable -> n
            n.parent?.isClickable == true -> n.parent
            else -> null
        } ?: return false
        return target.isEnabled && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun record() {
        scope.launch(Dispatchers.IO) {
            AppDb.get(applicationContext).dao().insert(SkipEvent(time = System.currentTimeMillis()))
        }
    }

    // ---------------- Floating button ----------------
    private fun updateBubble() {
        if (st.floating && bubble == null) addBubble()
        if (!st.floating && bubble != null) removeBubble()
        bubble?.let { styleBubble(it) }
    }

    private fun styleBubble(v: TextView) {
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (st.autoSkip) Color.parseColor("#00A86B") else Color.parseColor("#555555"))
            setStroke(3, Color.WHITE)
        }
        v.background = bg
        v.alpha = if (st.autoSkip) 0.95f else 0.75f
    }

    private fun addBubble() {
        val manager = wm ?: return
        val d = resources.displayMetrics.density
        val size = (52 * d).toInt()
        val tv = TextView(this).apply {
            text = "»"
            gravity = Gravity.CENTER
            textSize = 24f
            setTextColor(Color.WHITE)
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * d).toInt()
            y = (220 * d).toInt()
        }
        tv.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, ev: MotionEvent): Boolean {
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = ev.rawX; sy = ev.rawY; ox = lp.x; oy = lp.y; moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (ev.rawX - sx).toInt()
                        val dy = (ev.rawY - sy).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved) {
                            lp.x = ox + dx; lp.y = oy + dy
                            manager.updateViewLayout(v, lp)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            if (ev.eventTime - ev.downTime > 700) {
                                scope.launch { repo.setFloating(false) }   // long-press hides
                            } else {
                                scope.launch { repo.setAutoSkip(!st.autoSkip) }
                            }
                        }
                    }
                }
                return true
            }
        })
        try {
            manager.addView(tv, lp)
            bubble = tv
        } catch (_: Throwable) {
            bubble = null
        }
    }

    private fun removeBubble() {
        try { bubble?.let { wm?.removeView(it) } } catch (_: Throwable) { }
        bubble = null
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        removeBubble()
        scope.cancel()
        super.onDestroy()
    }
}
