package com.jubayer.skip

import android.content.ComponentName
import android.content.Context
import android.provider.Settings as AndroidSettings
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

/** Assumption used for the "time saved" estimate (see time_assumption string). */
const val SECONDS_PER_SKIP = 15

fun fmtTime(ctx: Context, skips: Int): String {
    val s = skips * SECONDS_PER_SKIP
    return ctx.getString(R.string.time_fmt, s / 3600, (s % 3600) / 60, s % 60)
}

fun isServiceEnabled(ctx: Context): Boolean {
    val v = AndroidSettings.Secure.getString(
        ctx.contentResolver, AndroidSettings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    val full = ComponentName(ctx, SkipService::class.java).flattenToString()
    val alt = ctx.packageName + "/" + SkipService::class.java.name
    return v.split(':').any { it.equals(full, true) || it.equals(alt, true) }
}

// ---------- Preferences (DataStore) ----------
private val Context.dataStore by preferencesDataStore(name = "settings")

data class AppSettings(
    val autoSkip: Boolean = false,
    val floating: Boolean = false,
    val theme: Int = 0,          // 0 system, 1 light, 2 dark
    val lang: String = "",       // "" system, bn, en, ar
    val saver: Boolean = false
)

class SettingsRepo(private val ctx: Context) {
    private val kAuto = booleanPreferencesKey("auto_skip")
    private val kFloat = booleanPreferencesKey("floating")
    private val kTheme = intPreferencesKey("theme")
    private val kLang = stringPreferencesKey("lang")
    private val kSaver = booleanPreferencesKey("saver")

    val flow: Flow<AppSettings> = ctx.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { p ->
            AppSettings(
                autoSkip = p[kAuto] ?: false,
                floating = p[kFloat] ?: false,
                theme = p[kTheme] ?: 0,
                lang = p[kLang] ?: "",
                saver = p[kSaver] ?: false
            )
        }

    suspend fun setAutoSkip(v: Boolean) { ctx.dataStore.edit { it[kAuto] = v } }
    suspend fun setFloating(v: Boolean) { ctx.dataStore.edit { it[kFloat] = v } }
    suspend fun setTheme(v: Int) { ctx.dataStore.edit { it[kTheme] = v } }
    suspend fun setLang(v: String) { ctx.dataStore.edit { it[kLang] = v } }
    suspend fun setSaver(v: Boolean) { ctx.dataStore.edit { it[kSaver] = v } }
}

// ---------- History (Room) ----------
@Entity(tableName = "skips")
data class SkipEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val time: Long
)

@Dao
interface SkipDao {
    @Insert
    suspend fun insert(e: SkipEvent)

    @Query("SELECT * FROM skips ORDER BY time DESC LIMIT 200")
    fun recent(): Flow<List<SkipEvent>>

    @Query("SELECT COUNT(*) FROM skips")
    fun total(): Flow<Int>

    @Query("SELECT COUNT(*) FROM skips WHERE time >= :since")
    fun since(since: Long): Flow<Int>

    @Query("DELETE FROM skips")
    suspend fun clear()
}

@Database(entities = [SkipEvent::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): SkipDao

    companion object {
        @Volatile private var instance: AppDb? = null
        fun get(ctx: Context): AppDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "skip.db")
                .build().also { instance = it }
        }
    }
}
